// Put all the javascript code here, that you want to execute in background.
